/*============================================================================
  File:     ExpensiveQueries.sql

  Summary:  Setup event monitoring to discover most expensive queries

  Date:     October 2009

  SQL Server Version: 10.0.2531.0 (SQL Server 2008 SP1)
------------------------------------------------------------------------------
  Written by Kimberly L. Tripp & Paul S. Randal, SQLskills.com

  For more scripts and sample code, check out http://www.SQLskills.com

  This script is intended as a supplement to the SQL Server 2008 Jumpstart or
  Metro training.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

USE MASTER;
GO

IF DATABASEPROPERTYEX ('production', 'Version') > 0
	DROP DATABASE production;
GO

-- Create a database to play with
CREATE DATABASE production;
GO

USE production;
GO

CREATE TABLE t1 (
	c1 INT IDENTITY, c2 UNIQUEIDENTIFIER ROWGUIDCOL DEFAULT NEWID(),
	c3 CHAR (5000) DEFAULT 'a');
CREATE CLUSTERED INDEX t1_CL ON t1 (c1);
CREATE NONCLUSTERED INDEX t1_NCL ON t1 (c2);
GO

SET NOCOUNT ON;
INSERT INTO t1 DEFAULT VALUES;
GO 1000

-- Get the database ID to plug into the event session
SELECT DB_ID ('production');
GO

-- Drop the session if it exists. 
IF EXISTS (
	SELECT * FROM sys.server_event_sessions
		WHERE name = 'EE_ExpensiveQueries')
    DROP EVENT SESSION EE_ExpensiveQueries ON SERVER;
GO

-- Create the event session
CREATE EVENT SESSION EE_ExpensiveQueries ON SERVER
ADD EVENT sqlserver.sql_statement_completed
	(ACTION (sqlserver.sql_text, sqlserver.plan_handle)
		WHERE sqlserver.database_id = 16 /*DBID*/
		AND cpu > 10 /*total ms of CPU time*/)
ADD TARGET package0.asynchronous_file_target
    (SET FILENAME = N'C:\SQLskills\EE_ExpensiveQueries.xel', 
    METADATAFILE = N'C:\SQLskills\EE_ExpensiveQueries.xem')
WITH (max_dispatch_latency = 1 seconds);
GO

-- Start the session
ALTER EVENT SESSION EE_ExpensiveQueries ON SERVER
STATE = START;
GO

-- Do some operations in the production database
USE production;
GO

SELECT COUNT (*) FROM t1 WHERE c1 > 500;
GO

SELECT SUM (c1) FROM t1 WHERE c3 LIKE 'a';
GO

ALTER INDEX t1_CL ON t1 REORGANIZE;
GO

ALTER INDEX t1_CL ON t1 REBUILD;
GO

USE master;
GO

-- Do we have any rows yet?
SELECT COUNT (*)
	FROM sys.fn_xe_file_target_read_file
	('C:\SQLskills\EE_ExpensiveQueries*.xel',
	'C:\SQLskills\EE_ExpensiveQueries*.xem', null, null);
GO

-- Extract the info
SELECT
	data
FROM 
	(SELECT CONVERT (XML, event_data) AS data
	FROM sys.fn_xe_file_target_read_file
		('C:\SQLskills\EE_ExpensiveQueries*.xel',
		'C:\SQLskills\EE_ExpensiveQueries*.xem', null, null)
	) entries;
GO

-- And now extract everything nicely
SELECT
	data.value (
		'(/event[@name=''sql_statement_completed'']/@timestamp)[1]',
			'DATETIME') AS [Time],
	data.value (
		'(/event/data[@name=''cpu'']/value)[1]', 'INT') AS [CPU (ms)],
	CONVERT (FLOAT, data.value (
		'(/event/data[@name=''duration'']/value)[1]', 'BIGINT')) / 1000000
		AS [Duration (s)],
	data.value (
		'(/event/action[@name=''sql_text'']/value)[1]',
			'VARCHAR(MAX)') AS [SQL Statement],
	SUBSTRING (data.value (
		'(/event/action[@name=''plan_handle'']/value)[1]',
			'VARCHAR(100)'), 15, 50) AS [Plan Handle]
FROM 
	(SELECT CONVERT (XML, event_data) AS data
	FROM sys.fn_xe_file_target_read_file
		('C:\SQLskills\EE_ExpensiveQueries*.xel',
		'C:\SQLskills\EE_ExpensiveQueries*.xem', null, null)
	) entries
ORDER BY [Time] DESC;
GO

-- Get the query plan for a query
SELECT query_plan FROM
	sys.dm_exec_query_plan (/*plug in a plan handle here*/);
GO

-- Now try the XML cracking in 'production' to trace it
-- and get the query plan
USE production;
GO

-- Stop the event session
ALTER EVENT SESSION EE_ExpensiveQueries ON SERVER
STATE = STOP;
GO


